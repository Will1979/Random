
package Beans;


import java.io.Serializable;



public class MyBean implements Serializable
{
    private String email;
    private String firstName;
   
  
    
    public MyBean()
    {
        email = "";
        firstName = "";
    }

    public void setEmail(String text)
    {
        this.email = text;
    }
      

    public String getEmail()
    {
        return email;
    }
    
     public void setFisrtName(String text)
    {
        this.firstName = text;
    }
     
       public String getFirstName()
    {
        return firstName;
    }
    
   
 
    
}

