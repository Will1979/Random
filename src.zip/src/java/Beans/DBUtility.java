package Beans;

import java.sql.*;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;



 


public class DBUtility 
{
  private Connection con;
    private Statement stat;
    private ResultSet rs;  
  
   
   public DBUtility()
   { 
      
   }
    private boolean dbConnection() 
    {
        String userName = "javaview_Java";
        String passWord = "JavaPeopleWork";
        String url = "jdbc:mysql://localhost:3306/javaview_info";
        
        try
        {
          
          Class.forName("com.mysql.jdbc.Driver");
             
          con = DriverManager.getConnection(url,userName, passWord);
          stat = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
             //stat.execute("create database javaview_info");
             //stat.execute("Create Table Users(id Integer,userName varchar(50), passWord varchar(50), primary key(id));");
            // stat.execute("Drop table Users;");
        }
        catch(SQLException e)
        {
          Logger.getLogger(MyBean.class.getName()).log(Level.SEVERE, null, e);
          return false;
        }
        catch(ClassNotFoundException ce)
        {
             
          return false;  
        }
        
      return true;  
     }
//  this method fillRows() is for setting up the table Users
    public boolean fillRows()
    {
        
        try 
        { 
            if(dbConnection())
            {
                rs = stat.executeQuery("Select * From Users;");
                for(int i =0; i < 1001; i++)
                {
                  rs.moveToInsertRow();
                  rs.updateInt(1, i);
                  rs.insertRow();
                }
            }
        }
         catch (SQLException ex) 
         {
            Logger.getLogger(MyBean.class.getName()).log(Level.SEVERE, null, ex);
            return false;
         }
    return true;
    }
   
    public boolean addData( Map<String,String[]> map) 
    {
       try 
       {  
          if(dbConnection())
           {
              rs = stat.executeQuery("Select * From Users;");
              
                while(rs.next())
                {  
                    String userName = rs.getString(2);
                    String passWord = rs.getString(3);
               
                        for(String key : map.keySet())
                        {
                            for(String val : map.get(key))
                            {
                                if(val.isEmpty())
                                {
                                   return false;
                                }
                                if(val.isEmpty())
                                {
                                   return false;
                                }
                            }
                        }
                     
                    if(userName == null & passWord == null)
                    {
                        for(String key : map.keySet())
                        {
                            for(String val : map.get(key))
                            {
                                if(key.equals("passWord"))
                                {
                                    passWord = val;
                                }
                                if( key.equals("userName"))
                                {
                                    userName = val;
                                }

                            }
                        }
                     rs.updateString(2,userName);
                     rs.updateString(3,passWord);
                     rs.updateRow();
                     stat.close();
                     con.close();
                    return true; 
                    }
                    else if(!userName.isEmpty() & !passWord.isEmpty())//checks if the username and password already exists in database, and rejects it if it does.
                    {
                        for(String key : map.keySet())
                        {
                            for(String val : map.get(key))
                            {
                                if(userName.equals(val))
                                {
                                  return false;
                                }
                                else if(passWord.equals(val))
                                { 
                                  return false;
                                }
                               
                            }
                        }
                    }//end second if
                }// end while loop
            }// end if(dbConnection) statement;
        }//end try
        catch (SQLException ex)           
        {
          Logger.getLogger(MyBean.class.getName()).log(Level.SEVERE, null, ex);
          return false;      
        } 
        finally
        {
           try {
               con.close();
              
           } 
           catch (SQLException ex) 
           {
               Logger.getLogger(MyBean.class.getName()).log(Level.SEVERE, null, ex);
               return false;
           }
        }
    return false; 
    }
   //checks if the username and password already exists in database, and rejects it if it does. 
   public boolean checkUserAndPassWord(Map<String,String[]>  map)
   {  
      
       String[] values = {null,null};
       try 
       {  
           if(dbConnection())
           {
               System.out.print("YOU ARE IN CHECKUSER AND PASSWORD METHOD\n");
              rs = stat.executeQuery("Select * From Users;");
               
                while(rs.next())
                {  
                    String userName = rs.getString(2);
                    String passWord = rs.getString(3);
                    String dbValuesCombined = userName + passWord;
                    String parameterValuesCombined = "";
                    if(userName != null & passWord != null)
                    {
                        for(String key : map.keySet())
                        {
                            for(String val : map.get(key))
                            {
                              if(key.equals("userName"))
                              {
                                  values[0] = val;
                                 break;
                              }
                              if(key.equals("passWord"))
                              {
                                  values[1] = val;
                                  break;
                              }
                           
                            }
                        }
                        parameterValuesCombined = values[0] + values[1];
                        if(parameterValuesCombined.equals(dbValuesCombined))
                        {
                          return true;
                        } 
                    }
               }
           }       
       }
       catch (SQLException ex)           
       {
          Logger.getLogger(DBUtility.class.getName()).log(Level.SEVERE, null, ex);
          return false;      
       } 
       finally
       {
           try {
               con.close();
                
           } 
           catch (SQLException ex) 
           {
               Logger.getLogger(DBUtility.class.getName()).log(Level.SEVERE, null, ex);
           }
         
        }   
     return false;      
   }
}

