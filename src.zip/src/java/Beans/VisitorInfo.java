/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;


import java.io.BufferedWriter;
import java.io.File;
import java.io.Serializable;
import java.nio.file.FileSystems;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author Washer
 */
public class VisitorInfo implements Serializable {
    
    private String path;
    public HttpServletResponse response;
    public HttpServletRequest request; 
    public HttpSession session;
    
    public VisitorInfo() 
    {
        
    }
    
    public void writeToFile(HttpServletRequest req, HttpServletResponse res, HttpSession session)
    {
        Charset charset = Charset.forName("UTF-8");
        path = "C:\\Users\\Washer\\Documents\\NetBeansProjects\\CoolPics\\src\\java\\Beans\\updates.txt";
        Path file = Paths.get(path);
      
        
        try( BufferedWriter bw = Files.newBufferedWriter(file, charset))
        {
            this.request = req;
            bw.write("Hello Man");
            bw.newLine();
            bw.write(path);
          
            
        } 
        catch (IOException ex) 
        {
            Logger.getLogger(VisitorInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
    
}
