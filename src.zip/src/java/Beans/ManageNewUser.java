/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.io.PrintWriter;
import java.io.Serializable;

import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




/**
 *
 * @author Washer
 */
public class ManageNewUser implements Serializable
{
   
   protected HttpSession session;
   protected PrintWriter out;
   protected HttpServletResponse response;
   private String sessionID;
   protected ServletContext sc;
   
    public ManageNewUser()
    {
        
    }
    
  
    
    public boolean isExisting(Map<String,String[]> formParameters)
            
    {
      
          
      DBUtility dbutil = new DBUtility();
            
                
             if(!dbutil.addData(formParameters))
             { 

                 return true;
             }
    return false; 
    }
    
   
}
