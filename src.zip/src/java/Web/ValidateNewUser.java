/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Web;


import java.io.IOException;
import Beans.ManageNewUser;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Washer
 */
public class ValidateNewUser extends HttpServlet {
 public HttpSession session;
 public static int count = 0;
    int counter =0;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @return 
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * 
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
       
     
        response.setContentType("text/html;charset=UTF-8");
       
     
        
            
           String ip = "Your approximate ip address is" + request.getRemoteAddr();
           
            Map<String, String[]> pMap =  request.getParameterMap();
           session = request.getSession();
          
        
           session.setAttribute("ip", ip);
           ManageNewUser checkUser = new ManageNewUser();  
           
           if(checkUser.isExisting(pMap))
           {  
                 log("THE USER ALREADY EXISTS");
                 String warning = "The user name is not strong enough, try another version.";   
                 session.setAttribute("warning", warning);
                response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                response.setHeader("Pragma", "no-cache");
                response.setDateHeader("Expires", 0);
                request.getRequestDispatcher("WEB-INF/NewAccount/CreateAccount.jsp").forward(request, response); 
           }
           else
           {
              
            log("A NEW ACCOUNT WAS CREATED");
               
               session.setAttribute("ip", ip);
               session.setAttribute("user", request.getParameter("userName"));
               response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
               response.setHeader("Pragma", "no-cache");
               response.setDateHeader("Expires", 0);
            
                response.sendRedirect("http://javaviews.com:8080/CoolPics/GetServlet");
           }
   
     }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
