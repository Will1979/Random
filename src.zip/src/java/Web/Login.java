/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Web;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import javax.servlet.http.HttpSession;
import Beans.DBUtility;
import java.util.Map;

import javax.servlet.http.Cookie;

/**
 *
 * @author Washer
 */

public class Login extends HttpServlet {
protected HttpSession session;
protected Cookie user3;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @return 
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.io.FileNotFoundException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, FileNotFoundException 
    {  
            DBUtility dbu = new DBUtility();
          
            Map<String,String[]> map = request.getParameterMap();
          
            response.setContentType("text/html;charset=UTF-8");
            String ip = "Your ip approximate ip address is &nbs" + request.getRemoteAddr();
             session = request.getSession();
             log(session.getId());
           
            
            if(!dbu.checkUserAndPassWord(map))
            {
              
               log("WHAT IS HAPPENING");
               String notMatching = "The User Name or Password does not match.";
               session.setAttribute("noMatch", notMatching);
              request.getRequestDispatcher("./index.jsp").forward(request, response);
              return;
            }
            else 
            {   
                log("SHOULD BE IN VALIDLOGIN");
                response.setContentType("text/html;charset=UTF-8"); 
                response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                response.setHeader("Pragma", "no-cache");
             
                response.setDateHeader("Expires", 0);
                session.setAttribute("ip", ip);
                session.setAttribute("user", request.getParameter("userName"));
                
               response.sendRedirect("http://javaviews.com:8080/CoolPics/GetServlet");
               
              
              
               
             
         
                 
                
            }
          
            
          
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
}
