/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Web;

import java.io.IOException;
import java.io.StringWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;


import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Washer
 */
public class StartIndex extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    
     Cookie user1;
     HashMap ajaxData;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
            response.setContentType("text/html;charset=UTF-8");
            HashMap<String, String> hm = new HashMap();
            hm.put("1", "This is ajax working to get a data from a java HashMAp in a servlet converted into a JSON file.");
            hm.put("2","Give me a thumbs up if you think ajax is cool!!");
            hm.put("3", "Give me two thumbs up if you like my site a little bit!!!");
            
            File file = new File(System.getProperty("user.home"));
            File jsonFile = new File(file,"ajaxCalls.json");
            Writer writer = new FileWriter(jsonFile);
            
           
//            JsonObject jsonObjectToFile = Json.createObjectBuilder(writer);
//             
//                 hm.keySet().forEach((key) -> {
//                     jsonObjectToFile.write(key,hm.get(key)).writeEnd();
//                });
                 
             
           
            log("Json object loaded up ready for file writing");
            
            
            
            HttpSession session = request.getSession(true);
            log(session.getId() + "--1");
            if(!session.isNew())
            {
                 log(session.getId() + "--2");
                session.invalidate();
                response.sendRedirect("./index.jsp");
            }
            else
            {
            log(session.getId() + "--3");
            user1 = new Cookie("testForCookies", "to check if cooikes are enabled");
            response.addCookie(user1);
            response.sendRedirect("./index.jsp");
            }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          

    }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
